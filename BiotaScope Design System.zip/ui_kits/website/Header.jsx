const {Logo,Button,IconButton}=window.BiotaScopeDesignSystem_24580f;
function SiteHeader({lang,setLang}){const [s,setS]=React.useState(false);React.useEffect(()=>{const f=()=>setS(window.scrollY>24);window.addEventListener('scroll',f);return()=>window.removeEventListener('scroll',f)},[]);
const t=lang==='es'?['Servicios','Resultados','Sobre BiotaScope','Contacto','Solicitar presupuesto']:['Services','Results','About','Contact','Request a quote'];
const ids=['servicios','resultados','sobre','contacto'];
return(<header style={{position:'sticky',top:0,zIndex:40,background:s?'var(--glass)':'transparent',backdropFilter:s?'blur(var(--blur-glass))':'none',borderBottom:'1px solid '+(s?'var(--border-subtle)':'transparent'),transition:'all var(--dur-slow) var(--ease-organic)'}}>
<div style={{maxWidth:'var(--container-max)',margin:'0 auto',padding:'0 var(--container-pad)',height:76,display:'flex',alignItems:'center',gap:32}}>
<a href="#top" style={{textDecoration:'none'}}><Logo size={24}/></a>
<nav className="sitenav" style={{display:'flex',gap:22,marginLeft:'auto'}}>{t.slice(0,4).map((l,i)=><a key={l} href={'#'+ids[i]} className="navlink">{l}</a>)}</nav>
<span className="navspacer" style={{marginLeft:'auto'}}></span><IconButton label="Cambiar idioma" variant="outline" size={38} onClick={()=>setLang(lang==='es'?'en':'es')}><span style={{fontSize:12,fontWeight:700}}>{lang==='es'?'EN':'ES'}</span></IconButton>
<Button size="sm" href="#contacto">{t[4]}</Button>
</div></header>);}
window.SiteHeader=SiteHeader;
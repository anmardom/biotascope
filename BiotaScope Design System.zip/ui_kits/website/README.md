# BiotaScope website UI kit
Recreation of the single-page marketing site at https://www.biotascope.com/ re-skinned in the new organic identity. Structure and copy follow the live site verbatim (ES + EN).

Sections: `SiteHeader` (sticky, glass on scroll, EN/ES toggle) · `Hero` (+ tech strip) · `Services` (4 service cards) · `Results` (6 figures, category tabs, lightbox with ←/→/Esc) · `About` (dark abisal band) · `Contact` (validated form → toast) · `SiteFooter`.

Result figures are placeholders — the real PNGs (qiime2-taxa-barplot, picrust2-functional, krona-chart, volcano-differential, humann3-heatmap, humann3-pathways-barplot) could not be downloaded; drop them in and swap the placeholder in `Results.jsx`.
Category tabs on the results gallery are an addition (not on the live site).

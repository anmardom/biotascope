/** Rounded-square checkbox with label (consent, filters). */
export interface CheckboxProps { label?: React.ReactNode; checked?: boolean; defaultChecked?: boolean; onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void; disabled?: boolean; error?: boolean; style?: React.CSSProperties; }
export declare function Checkbox(props: CheckboxProps): JSX.Element;

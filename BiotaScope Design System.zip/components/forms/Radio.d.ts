/** Single radio with label. Use RadioGroup for controlled sets. */
export interface RadioProps { label?: React.ReactNode; name?: string; value?: string; checked?: boolean; defaultChecked?: boolean; onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void; disabled?: boolean; style?: React.CSSProperties; }
export declare function Radio(props: RadioProps): JSX.Element;
export interface RadioGroupProps { name: string; options: string[]; value?: string; onChange?: (v: string) => void; direction?: 'row' | 'column'; style?: React.CSSProperties; }
export declare function RadioGroup(props: RadioGroupProps): JSX.Element;

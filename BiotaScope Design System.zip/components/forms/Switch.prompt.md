Toggle for binary settings (e.g. "Incluir predicción funcional").
```jsx
<Switch label="Incluir PICRUSt2" defaultChecked />
```

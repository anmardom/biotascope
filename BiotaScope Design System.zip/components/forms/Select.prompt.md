Dropdown field, e.g. choosing the service in the quote form.
```jsx
<Select label="Servicio" options={['Meta-barcoding','Análisis taxonómico','Perfilado funcional','Bioinformática general','Otra consulta']} />
```

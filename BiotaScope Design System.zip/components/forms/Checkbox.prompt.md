Checkbox with label — consent lines and multi-select filters.
```jsx
<Checkbox label="Acepto que se use mi email para responder a esta consulta." />
```

/** Labelled text input / textarea with hint + error message. */
export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>,'style'> {
  label?: string;
  optional?: boolean;
  hint?: string;
  error?: string;
  multiline?: boolean;
  rows?: number;
  style?: React.CSSProperties;
}
export declare function Input(props: InputProps): JSX.Element;

Radio button for mutually exclusive choices (e.g. tipo de muestra).
```jsx
<RadioGroup name="muestra" options={['Heces','Suelo','Agua']} value={v} onChange={setV} direction="row" />
```

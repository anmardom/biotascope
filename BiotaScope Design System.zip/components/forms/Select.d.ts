/** Native select styled as a BiotaScope field. */
export interface SelectProps {
  label?: string; optional?: boolean; hint?: string; error?: string;
  options: (string | { value: string; label: string })[];
  placeholder?: string;
  value?: string; defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  id?: string; name?: string;
  style?: React.CSSProperties;
}
export declare function Select(props: SelectProps): JSX.Element;

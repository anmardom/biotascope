Labelled text field (and textarea via multiline) for the contact / quote form.
```jsx
<Input label="Nombre" placeholder="Tu nombre" />
<Input label="Organización" optional />
<Input label="Email" error="Escribe un email válido." />
<Input label="Mensaje" multiline rows={5} />
```
- Error copy is a short imperative ("Escribe tu nombre.").

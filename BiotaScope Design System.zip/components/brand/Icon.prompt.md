Original BiotaScope service icon — use for service cards, feature lists and section markers.
```jsx
<Icon name="meta-barcoding" size={56} />
<Icon name="rna-seq" tone="baya" />
<Icon name="microbiota" blob={false} size={24} color="var(--agar-50)" />
```
- 14 names: meta-barcoding, analisis-taxonomico, perfilado-funcional, bioinformatica, microbiota, microorganismos, muestras-ambientales, farmacogenomica, rna-seq, scrna-seq, chip-seq, variant-calling, resultados, consulta.
- Each icon has a default blob tone; on dark grounds pass color="var(--agar-50)".

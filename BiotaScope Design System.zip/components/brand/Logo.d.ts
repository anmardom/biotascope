/** BiotaScope logo: minimal lens ring + off-centre cell isotype, bold lowercase geometric wordmark, optional mono tagline. */
export interface LogoProps {
  /** Wordmark font-size in px; symbol scales to 1.25×. Default 32 */
  size?: number;
  tone?: 'light' | 'inverse' | 'mono';
  symbolOnly?: boolean;
  /** true = "Meta-omic bioinformatics", or custom string. Mono, under the wordmark. */
  tagline?: boolean | string;
  style?: React.CSSProperties;
}
export declare function Logo(props: LogoProps): JSX.Element;
export interface LogoSymbolProps { size?: number; tone?: 'light' | 'inverse' | 'mono'; style?: React.CSSProperties; }
export declare function LogoSymbol(props: LogoSymbolProps): JSX.Element;

export type IconName = 'meta-barcoding'|'analisis-taxonomico'|'perfilado-funcional'|'bioinformatica'|'microbiota'|'microorganismos'|'muestras-ambientales'|'farmacogenomica'|'rna-seq'|'scrna-seq'|'chip-seq'|'variant-calling'|'resultados'|'consulta';
/** BiotaScope duotone service icon (48px grid, 2px round ink stroke over an organic colour blob). */
export interface IconProps {
  name: IconName;
  /** px, default 48. Use ≥32 so the blob reads. */
  size?: number;
  /** Override blob tone: ambar | biota | liquen | arcilla | baya | agua, or any CSS color */
  tone?: string;
  /** Hide the blob for small inline use */
  blob?: boolean;
  /** Stroke colour, default var(--abisal-800) */
  color?: string;
  title?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;

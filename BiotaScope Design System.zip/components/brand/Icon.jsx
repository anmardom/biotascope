import React from 'react';
import { ICONS, ICON_BLOB, ICON_TONES } from './iconData.js';
export function Icon({name,size=48,tone,blob=true,color='var(--abisal-800)',style,title}){const d=ICONS[name];if(!d)return null;const fill=ICON_TONES[tone||d.tone]||tone;return(<svg viewBox="0 0 48 48" width={size} height={size} role={title?'img':undefined} aria-hidden={title?undefined:true} style={{display:'block',flex:'none',...style}}>{title&&<title>{title}</title>}{blob&&<path d={ICON_BLOB} fill={fill} transform={'rotate('+d.rotate+' 26 24)'}/>}<g fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" dangerouslySetInnerHTML={{__html:d.paths.split('#0F3D3E').join(color)}}/></svg>);}
export const ICON_NAMES=Object.keys(ICONS);

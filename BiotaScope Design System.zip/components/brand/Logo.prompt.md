BiotaScope logo lockup (lens isotype + lowercase "biotascope" wordmark) for headers, footers and covers.
```jsx
<Logo size={26} />
<Logo size={40} tagline />            {/* adds mono "Meta-omic bioinformatics" */}
<Logo tone="inverse" size={24} />     {/* on --abisal-800 */}
<LogoSymbol size={40} />
```
- tone: light (on white), inverse (on abisal), mono (currentColor).
- Wordmark is always lowercase Sora 700, tracking −0.055em. Never recolour the dot or re-type the wordmark; min symbol size 16px.

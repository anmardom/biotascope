// Generated: BiotaScope service icon set (48px grid, 2px round stroke + organic blob)
export const ICON_BLOB="M28 7c8.5 0 14 6.8 14 15.2 0 9.6-6.4 18.8-15.6 18.8C18 41 11 35.4 11 26.6 11 16.2 19 7 28 7z";
export const ICON_TONES={"ambar":"#EFC27E","biota":"#8CC7B8","liquen":"#D3DC7C","arcilla":"#E8A686","baya":"#D69BB8","agua":"#A8CAD6"};
export const ICONS={
 "meta-barcoding": {
  "label": "Meta-barcoding",
  "tone": "ambar",
  "rotate": 0,
  "paths": "<rect x=\"7\" y=\"11\" width=\"34\" height=\"26\" rx=\"6\"/><path d=\"M13 17v14M17 17v14M20 17v14M25 17v14M29 17v14M32 17v14M36 17v14\" stroke-width=\"2\"/><path d=\"M13 17v14M25 17v14\" stroke-width=\"3.2\"/>"
 },
 "analisis-taxonomico": {
  "label": "Análisis taxonómico",
  "tone": "biota",
  "rotate": 40,
  "paths": "<path d=\"M6 24h8M14 14v20M14 14h10M14 34h10M24 9v10M24 9h9M24 19h9M24 29v10M24 29h9M24 39h9\"/><circle cx=\"36.5\" cy=\"9\" r=\"2.8\"/><circle cx=\"36.5\" cy=\"19\" r=\"2.8\"/><circle cx=\"36.5\" cy=\"29\" r=\"2.8\"/><circle cx=\"36.5\" cy=\"39\" r=\"2.8\"/>"
 },
 "perfilado-funcional": {
  "label": "Perfilado funcional",
  "tone": "liquen",
  "rotate": -30,
  "paths": "<circle cx=\"11\" cy=\"12\" r=\"4\"/><circle cx=\"37\" cy=\"12\" r=\"4\"/><circle cx=\"24\" cy=\"25\" r=\"5\"/><circle cx=\"12\" cy=\"38\" r=\"4\"/><circle cx=\"37\" cy=\"37\" r=\"4\"/><path d=\"M14 15l6.5 6.5M34 15l-6.5 6.5M20.5 28.5L15 35M28 29l6 5.5\"/><path d=\"M33 34.5l1.2-3.4 3.3 1.3\" />"
 },
 "bioinformatica": {
  "label": "Bioinformática general",
  "tone": "agua",
  "rotate": 20,
  "paths": "<rect x=\"6\" y=\"9\" width=\"36\" height=\"30\" rx=\"6\"/><path d=\"M6 16h36\"/><path d=\"M15 23l-4 4 4 4M21 33l5-12M31 23l4 4-4 4\"/>"
 },
 "microbiota": {
  "label": "Microbiota",
  "tone": "baya",
  "rotate": -60,
  "paths": "<rect x=\"6\" y=\"16\" width=\"20\" height=\"9\" rx=\"4.5\" transform=\"rotate(-32 16 20.5)\"/><circle cx=\"32\" cy=\"14\" r=\"5\"/><circle cx=\"33\" cy=\"33\" r=\"7\"/><circle cx=\"15\" cy=\"35\" r=\"4\"/><circle cx=\"33\" cy=\"33\" r=\"1.6\" fill=\"#0F3D3E\" stroke=\"none\"/><path d=\"M38 20.5a3 3 0 0 1 3 3\"/>"
 },
 "microorganismos": {
  "label": "Microorganismos",
  "tone": "ambar",
  "rotate": 120,
  "paths": "<rect x=\"9\" y=\"17\" width=\"26\" height=\"12\" rx=\"6\" transform=\"rotate(-20 22 23)\"/><path d=\"M34.5 17.5c2.5-2 4-1 5.5-3s1.5-3.5 3-4.5M35.5 23c3 0 3.5 2 6 2M8.5 30c-2 2-1 4-3 5.5\"/><circle cx=\"18\" cy=\"24.5\" r=\"1.6\" fill=\"#0F3D3E\" stroke=\"none\"/><circle cx=\"25\" cy=\"21.5\" r=\"1.6\" fill=\"#0F3D3E\" stroke=\"none\"/>"
 },
 "muestras-ambientales": {
  "label": "Muestras ambientales",
  "tone": "liquen",
  "rotate": 70,
  "paths": "<path d=\"M17 6h14M19 6v27a5 5 0 0 0 10 0V6\"/><path d=\"M19 24h10\"/><path d=\"M24 24c0-6 3-9.5 8.5-10 0 5.5-3 9-8.5 10z\"/><path d=\"M8 42c5-3 11-3 16 0s11 3 16 0\"/>"
 },
 "farmacogenomica": {
  "label": "Farmacogenómica",
  "tone": "arcilla",
  "rotate": -10,
  "paths": "<rect x=\"6\" y=\"20\" width=\"24\" height=\"12\" rx=\"6\" transform=\"rotate(-40 18 26)\"/><path d=\"M13.5 30.5l9-7.5\"/><path d=\"M32 6c0 5 10 7 10 12s-10 7-10 12 10 7 10 12M42 6c0 5-10 7-10 12s10 7 10 12-10 7-10 12M33.5 12h7M33.5 24h7M33.5 36h7\"/>"
 },
 "rna-seq": {
  "label": "RNA-seq",
  "tone": "biota",
  "rotate": 160,
  "paths": "<path d=\"M5 24c4-9 8-9 12 0s8 9 12 0 8-9 12 0\"/><path d=\"M9 18v-5M17 24v-6M25 30v5M33 18v-5M41 24v-6\"/><circle cx=\"9\" cy=\"11\" r=\"2\"/><circle cx=\"33\" cy=\"11\" r=\"2\"/><circle cx=\"25\" cy=\"37\" r=\"2\"/>"
 },
 "scrna-seq": {
  "label": "scRNA-seq",
  "tone": "baya",
  "rotate": 90,
  "paths": "<circle cx=\"17\" cy=\"19\" r=\"10\"/><circle cx=\"17\" cy=\"19\" r=\"3.5\"/><circle cx=\"34\" cy=\"33\" r=\"2\"/><circle cx=\"39\" cy=\"27\" r=\"2\"/><circle cx=\"31\" cy=\"40\" r=\"2\"/><circle cx=\"40\" cy=\"37\" r=\"2\"/><circle cx=\"24\" cy=\"38\" r=\"2\"/><path d=\"M24 26l5 5\"/>"
 },
 "chip-seq": {
  "label": "ChIP-seq",
  "tone": "ambar",
  "rotate": -80,
  "paths": "<path d=\"M5 40h38\"/><path d=\"M5 40c3 0 4-3 6-3s3-17 5.5-17 3 17 5.5 17 2-9 4-9 2.5 9 4.5 9 3-25 5.5-25S39 40 43 40\"/>"
 },
 "variant-calling": {
  "label": "Variant calling",
  "tone": "arcilla",
  "rotate": 45,
  "paths": "<path d=\"M12 5c0 7 16 9 16 19s-16 12-16 19M28 5c0 7-16 9-16 19s16 12 16 19M14.5 11h11M13 24h14M14.5 37h11\"/><circle cx=\"36\" cy=\"24\" r=\"5.5\"/><path d=\"M27 24h3.5\"/>"
 },
 "resultados": {
  "label": "Resultados publicables",
  "tone": "agua",
  "rotate": -40,
  "paths": "<path d=\"M11 6h18l9 9v27H11z\"/><path d=\"M29 6v9h9\"/><path d=\"M17 36v-6M22.5 36v-11M28 36v-8M32.5 36v-4\"/>"
 },
 "consulta": {
  "label": "Plan de análisis",
  "tone": "liquen",
  "rotate": 10,
  "paths": "<path d=\"M8 12a5 5 0 0 1 5-5h22a5 5 0 0 1 5 5v15a5 5 0 0 1-5 5H20l-8 7v-7h1a5 5 0 0 1-5-5z\"/><path d=\"M16 17h16M16 23h10\"/>"
 }
};

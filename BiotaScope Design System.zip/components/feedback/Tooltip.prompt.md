Short hint on hover/focus — ideal for expanding tool names.
```jsx
<Tooltip content="Quantitative Insights Into Microbial Ecology"><Tag>QIIME2</Tag></Tooltip>
```

/** Modal dialog over an abisal scrim. Closes on Escape / backdrop click. */
export interface DialogProps { open: boolean; onClose?: () => void; title?: React.ReactNode; children?: React.ReactNode; footer?: React.ReactNode; width?: number; style?: React.CSSProperties; }
export declare function Dialog(props: DialogProps): JSX.Element | null;

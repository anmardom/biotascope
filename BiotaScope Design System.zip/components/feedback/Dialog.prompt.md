Modal for confirmations and focused tasks (e.g. "Consulta enviada").
```jsx
<Dialog open={o} onClose={()=>setO(false)} title="Consulta enviada" footer={<Button onClick={()=>setO(false)}>Entendido</Button>}>Te respondemos en 48 h.</Dialog>
```

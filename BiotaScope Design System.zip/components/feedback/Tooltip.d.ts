/** Hover/focus hint, e.g. explaining a tool acronym. */
export interface TooltipProps { content: React.ReactNode; placement?: 'top' | 'bottom'; children: React.ReactNode; style?: React.CSSProperties; }
export declare function Tooltip(props: TooltipProps): JSX.Element;

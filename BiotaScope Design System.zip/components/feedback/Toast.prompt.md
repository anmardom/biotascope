Transient confirmation, bottom-right, auto-dismiss ~5s.
```jsx
<Toast title="Consulta enviada">Te respondemos con una primera valoración.</Toast>
<Toast tone="danger" title="No se pudo enviar">Revisa tu conexión.</Toast>
```

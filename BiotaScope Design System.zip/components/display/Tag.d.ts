/** Outlined chip for tools/technologies (QIIME2, Kraken2…) and filters. Mono by default. */
export interface TagProps { children?: React.ReactNode; mono?: boolean; selected?: boolean; onClick?: () => void; onRemove?: () => void; style?: React.CSSProperties; }
export declare function Tag(props: TagProps): JSX.Element;

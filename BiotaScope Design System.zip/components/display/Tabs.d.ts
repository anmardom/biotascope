/** Segmented pill tabs or underline tabs. */
export interface TabsProps { tabs: (string | { value: string; label: React.ReactNode })[]; value?: string; defaultValue?: string; onChange?: (v: string) => void; variant?: 'pill' | 'underline'; style?: React.CSSProperties; }
export declare function Tabs(props: TabsProps): JSX.Element;

Tool/technology chip, e.g. the tool list under each service.
```jsx
<div style={{display:'flex',gap:8,flexWrap:'wrap'}}><Tag>QIIME2</Tag><Tag>PICRUSt2</Tag><Tag>16S</Tag></div>
<Tag selected onClick={…}>Shotgun</Tag>
```

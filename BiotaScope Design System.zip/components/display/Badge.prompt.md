Status or category pill ("Entregado", "En análisis", "Nuevo").
```jsx
<Badge tone="biota" dot>Entregado</Badge>
<Badge tone="ambar">En análisis</Badge>
```

Tabs to switch views (e.g. result categories: Taxonomía / Funcional / Diferencial).
```jsx
<Tabs tabs={['Todos','Taxonomía','Funcional']} onChange={setCat} />
<Tabs variant="underline" tabs={['Resumen','Figuras','Tablas']} />
```

/** Small status / category pill. */
export interface BadgeProps { tone?: 'neutral'|'biota'|'ambar'|'arcilla'|'baya'|'agua'|'liquen'|'inverse'; dot?: boolean; children?: React.ReactNode; style?: React.CSSProperties; }
export declare function Badge(props: BadgeProps): JSX.Element;

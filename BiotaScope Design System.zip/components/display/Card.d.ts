/** Soft rounded container; raised (cream + hairline), tint (biota), warm (ámbar), inverse (abisal). */
export interface CardProps { tone?: 'raised' | 'tint' | 'warm' | 'inverse'; interactive?: boolean; padding?: number | string; radius?: string; onClick?: () => void; children?: React.ReactNode; style?: React.CSSProperties; }
export declare function Card(props: CardProps): JSX.Element;

Base container for service cards, result figures, callouts.
```jsx
<Card interactive><Icon name="meta-barcoding"/><h3>Meta-barcoding</h3>…</Card>
<Card tone="tint">…</Card>
```
- interactive adds a slow lift (-3px + shadow-md) on hover. No coloured left borders.

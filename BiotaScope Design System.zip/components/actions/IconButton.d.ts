/** Circular icon-only button (menu, close, carousel arrows, language). */
export interface IconButtonProps {
  variant?: 'ghost' | 'outline' | 'solid' | 'inverse';
  /** px, default 40 (min 44 on touch) */
  size?: number;
  /** Accessible label — required */
  label: string;
  onClick?: (e: React.MouseEvent) => void;
  disabled?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;

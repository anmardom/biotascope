Pill button for all calls-to-action ("Solicitar presupuesto", "Ver resultados").
```jsx
<Button>Solicitar presupuesto</Button>
<Button variant="secondary">Ver resultados</Button>
<Button variant="accent" size="lg" iconRight={<span>→</span>}>Cuéntanos tu proyecto</Button>
```
- primary = deep abisal (default CTA). accent = ámbar, max one per view. secondary = outlined. ghost = text-like. inverse = on dark sections.
- Hover shifts hue (abisal→biota, ámbar→darker ámbar); press scales to .97.

Round icon-only button for menus, close, lightbox prev/next.
```jsx
<IconButton label="Cerrar" variant="outline">×</IconButton>
<IconButton label="Siguiente" variant="solid">›</IconButton>
```
- Always pass label. Children: a Lucide icon or a single glyph (×, ‹, ›).

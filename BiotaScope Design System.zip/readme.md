# BiotaScope Design System

BiotaScope is a specialised **meta-omic bioinformatics service** (Spain, ES/EN). It turns raw sequencing data from microbiota, environmental samples and other omics into publishable figures, tables and documentation for research groups and companies. Contact: angel@biotascope.com.

Services (from the live site): **Meta-barcoding** (16S/ITS, QIIME2, PICRUSt2) · **Análisis taxonómico** (Kraken2, Bracken, Krona, shotgun) · **Perfilado funcional** (HUMAnN3, MetaCyc, UniRef) · **Bioinformática general** (RNA-seq, scRNA-seq, ChIP-seq, variant calling).

**Brief:** scientific but more human — closer to the competitor Darwin Bioprospecting (organic, innovative, vitalist) without losing prestige. Warm, varied, organic palette (not cold). A new, more innovative logo inspired by the current one. An original service icon set in the spirit of Duponte ADN.

## Revision log
- v2: removed cream/paper backgrounds → clean whites; serif headings → Sora sans; logo redrawn minimal with lowercase geometric wordmark + mono tagline.

## Sources
- Live site: https://www.biotascope.com/ (single-page; copy, structure and sections read from it; meta theme-color `#003b4d`).
- Competitor reference: https://darwinbioprospecting.com/ (tone: "a planet of useful microbes", organic storytelling).
- Icon style reference: https://duponteadn.com/ — **could not be accessed**; the icon style is inferred (see Iconography).
- User-supplied imagery (`uploads/` → `assets/images/`): microorganismos, microbiota, farmacogenomica, laboratorio.
- No codebase, Figma, font files or original logo files were provided.

## Index
- `styles.css` — entry point (imports only) → `tokens/fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css`
- `assets/logo.svg`, `logo-inverse.svg`, `logo-mono.svg` — Scope symbol
- `assets/icons/*.svg` — 14 service icons; `assets/images/*.png` — brand imagery
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand)
- `components/` — React primitives (below), each with `.d.ts` + `.prompt.md` + a directory card
- `ui_kits/website/` — biotascope.com recreation (index.html + section JSX)
- `SKILL.md` — Agent Skill entry; `thumbnail.html` — project tile

## Components
- **brand/**: `Logo`, `LogoSymbol`, `Icon` (+ `ICON_NAMES`)
- **actions/**: `Button`, `IconButton`
- **forms/**: `Input`, `Select`, `Checkbox`, `Radio`, `RadioGroup`, `Switch`
- **display/**: `Card`, `Badge`, `Tag`, `Tabs`
- **feedback/**: `Dialog`, `Toast`, `Tooltip`

No source component library existed, so this is a standard set sized to a marketing/service site. **Intentional additions:** `Logo`/`LogoSymbol` (brand mark as component so it can take tones) and `Icon` (renders the original icon set inline with tone/stroke overrides).

## UI kits
- `ui_kits/website/` — Header, Hero, Services, Results (lightbox), About, Contact (validated form + toast), Footer. ES/EN toggle.

---

## CONTENT FUNDAMENTALS
- **Language:** Spanish first (es_ES), English alternate. Keep both in sync; don't translate tool names.
- **Voice:** expert, calm, collaborative. First-person plural for BiotaScope ("Trabajamos con…", "te respondemos"), informal **tú** for the reader ("Cuéntanos tu proyecto", "resultados que puedes publicar"). Never "usted".
- **Tone:** precise but human — outcomes over jargon. Lead with what the researcher gets ("De secuencias crudas a resultados que puedes publicar"), then name tools as proof.
- **Casing:** sentence case everywhere — headlines, buttons, nav ("Solicitar presupuesto", "Qué hacemos"). Eyebrows are uppercase via CSS only.
- **Tool names** keep canonical casing and live in mono tags: QIIME2, PICRUSt2, Kraken2, HUMAnN3, 16S/ITS, scRNA-seq.
- **Length:** short declarative sentences; service descriptions ≤ 30 words; one idea per paragraph.
- **Forms:** labels are single nouns ("Nombre", "Servicio"); errors are short imperatives ending in a period ("Escribe un email válido.").
- **Vitalist accent:** one living/organic word per headline may be coloured Biota (no italics) — e.g. "resultados que puedes **publicar**". Use sparingly.
- **No emoji. No exclamation marks.** No hype ("revolucionario", "líder"). Numbers only when real (reads, samples, ASVs).

## VISUAL FOUNDATIONS
- **Palette:** warm, living, microscope-derived. Ink is *Abisal* (deep warm teal, evolved from the site's #003b4d); primary is *Biota* teal-green; accents come straight from the stained-cell imagery — *Ámbar* (ochre), *Liquen* (chartreuse), *Arcilla* (clay), *Baya* (berry), *Agua* (watery blue). Neutrals are clean lab whites (*Agar* 50 = #FFFFFF, faint green-grey 100–300) and *Tinta* green-grey inks. **No cream, canvas or paper tones**; never pure black.
- **Colour ratio:** ~70% agar neutrals, ~20% abisal/biota, ≤10% organic accents. Ámbar is the single "warm action" accent; max one ámbar CTA per view.
- **Type:** *Sora* (geometric sans, 600, tight −0.03/−0.045em) for display & headings — modern, innovative; *Hanken Grotesk* for body/UI; *JetBrains Mono* for tools, data and the logo tagline. **No serifs.**
- **Spacing:** 4-based scale; generous section rhythm (`--section-y` 64–120px); 1200px container; lots of air around headlines.
- **Backgrounds:** white page; alternating very light green-grey (`--agar-100`) bands; one dark abisal band per page (About / footer). Decorative **blurred cell blobs** (asymmetric `--radius-cell`, `blur(70px)`, ~35% opacity) used sparingly. No grain/paper texture, no hard gradients, no bluish-purple.
- **Imagery:** luminous micrographs (teal ground, amber/green/berry glowing cells), glassy microbiota bubbles, glowing DNA; plus human lab scenes. Warm grade, soft glow, shallow depth. Crop hero images into the organic cell shape or large-radius rectangles.
- **Corner radii:** soft — 10px fields, 16px small cards, 24px cards, 36px dialogs/forms, pill buttons & tags. The asymmetric cell radius is reserved for imagery and blobs.
- **Cards:** white (`--surface-card`) + 1px agar-300 hairline + `--shadow-xs`; interactive cards lift −3px to `--shadow-md` over 480ms. Tint/warm variants have no border. **No coloured left-border cards.**
- **Shadows:** abisal-tinted rgba, low and diffuse; never grey-black. A lichen **glow** ring is used for "live" status dots.
- **Borders:** 1px hairlines in agar-300; 1.5px for inputs and outlined buttons.
- **Motion:** `--ease-organic` (fast start, long soft settle); 140/240/480ms. Fades + small translates (3–4px). No bounces, no spins. Respect reduced-motion.
- **Hover:** hue shift rather than opacity — abisal → biota, ámbar → darker ámbar; ghost surfaces fill with agar-200; links go from biota-700 to ámbar-700.
- **Press:** scale .97 on buttons. **Focus:** 3px cream gap + 2px biota ring (`--focus-ring`), inputs get a soft 4px biota halo.
- **Transparency & blur:** sticky header becomes white glass (80% + 14px blur) after scrolling; modal scrims are abisal 72% + 4–6px blur. Nowhere else.
- **Layout:** sticky header (76px); asymmetric 2-column heroes; auto-fit card grids; content max 1200px.

## ICONOGRAPHY
- **Service icons** (`assets/icons/*.svg`, `Icon` component): 14 **original** icons drawn for BiotaScope — 48px grid, 2px round-cap/round-join Abisal stroke, sitting over an offset **organic colour blob** (each icon has its own tone from the accent palette, rotated for variety). This duotone "line over blob" style is our interpretation of the Duponte ADN reference, which couldn't be loaded — please confirm.
- Set: meta-barcoding, analisis-taxonomico, perfilado-funcional, bioinformatica, microbiota, microorganismos, muestras-ambientales, farmacogenomica, rna-seq, scrna-seq, chip-seq, variant-calling, resultados, consulta.
- Use at 40–64px in service cards / feature lists; on dark grounds pass `color="var(--agar-50)"` and a translucent tone.
- **UI glyphs** (arrows, close, chevrons): simple unicode (→ × ‹ ›) or, for richer UI, **Lucide** from CDN (2px stroke matches). No icon font. **No emoji.**
- **Logo:** minimal isotype — a thick lens ring (field of view) with one off-centre Biota cell: observation + life, reduced to two shapes. Wordmark "biotascope", lowercase, Sora 700, tracking −0.055em; optional mono tagline "Meta-omic bioinformatics" (reference: Darwin's geometric wordmark + mono tagline). Min symbol 16px; clear space = ring stroke × 2.

## Fonts
Google Fonts loaded via `tokens/fonts.css` (Sora, Hanken Grotesk, JetBrains Mono). No brand font files were supplied — replace with licensed files + `@font-face` if the brand has them.

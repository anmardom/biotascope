/* @ds-bundle: {"format":4,"namespace":"BiotaScopeDesignSystem_24580f","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"Icon","sourcePath":"components/brand/Icon.jsx"},{"name":"ICON_NAMES","sourcePath":"components/brand/Icon.jsx"},{"name":"LogoSymbol","sourcePath":"components/brand/Logo.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"ICON_BLOB","sourcePath":"components/brand/iconData.js"},{"name":"ICON_TONES","sourcePath":"components/brand/iconData.js"},{"name":"ICONS","sourcePath":"components/brand/iconData.js"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"Tabs","sourcePath":"components/display/Tabs.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"RadioGroup","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"d9b2181795db","components/actions/IconButton.jsx":"c499d271745f","components/brand/Icon.jsx":"bf3b7c8688b8","components/brand/Logo.jsx":"7ac750a16a12","components/brand/iconData.js":"ad3d5c81bf35","components/display/Badge.jsx":"9410cf1e4b1b","components/display/Card.jsx":"b82903fa460f","components/display/Tabs.jsx":"09216a667f02","components/display/Tag.jsx":"6d5a0b81c58d","components/feedback/Dialog.jsx":"ad30da528ce8","components/feedback/Toast.jsx":"8160c7b0f444","components/feedback/Tooltip.jsx":"ecb9ce439daf","components/forms/Checkbox.jsx":"ec3fe60ab8c9","components/forms/Input.jsx":"917c8d5fc0a7","components/forms/Radio.jsx":"7158888a4931","components/forms/Select.jsx":"3b8712d5ee28","components/forms/Switch.jsx":"ea638841007c","ui_kits/website/About.jsx":"eaca7ee319c5","ui_kits/website/Contact.jsx":"ebc5abad10bc","ui_kits/website/Footer.jsx":"ae7197ee0ff6","ui_kits/website/Header.jsx":"1e809cbc9114","ui_kits/website/Hero.jsx":"3aec0bee8364","ui_kits/website/Results.jsx":"f1357d32e5c5","ui_kits/website/Services.jsx":"a115a61d53b7"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.BiotaScopeDesignSystem_24580f = window.BiotaScopeDesignSystem_24580f || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
const V = {
  primary: {
    bg: 'var(--action-primary)',
    bgH: 'var(--action-primary-hover)',
    fg: 'var(--text-inverse)',
    bd: 'transparent'
  },
  accent: {
    bg: 'var(--action-accent)',
    bgH: 'var(--action-accent-hover)',
    fg: 'var(--abisal-900)',
    fgH: 'var(--agar-50)',
    bd: 'transparent'
  },
  secondary: {
    bg: 'transparent',
    bgH: 'var(--biota-100)',
    fg: 'var(--abisal-800)',
    bd: 'var(--abisal-800)'
  },
  ghost: {
    bg: 'transparent',
    bgH: 'var(--agar-200)',
    fg: 'var(--abisal-800)',
    bd: 'transparent'
  },
  inverse: {
    bg: 'var(--agar-50)',
    bgH: 'var(--liquen-200)',
    fg: 'var(--abisal-800)',
    bd: 'transparent'
  }
};
const S = {
  sm: {
    h: 36,
    px: 16,
    fs: 14
  },
  md: {
    h: 46,
    px: 22,
    fs: 15.5
  },
  lg: {
    h: 56,
    px: 30,
    fs: 17
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  disabled,
  fullWidth,
  href,
  onClick,
  type = 'button',
  children,
  style
}) {
  const [h, setH] = React.useState(false);
  const [a, setA] = React.useState(false);
  const v = V[variant] || V.primary,
    s = S[size] || S.md;
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, {
    href: href,
    type: href ? undefined : type,
    onClick: disabled ? undefined : onClick,
    disabled: disabled,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => {
      setH(false);
      setA(false);
    },
    onMouseDown: () => setA(true),
    onMouseUp: () => setA(false),
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : undefined,
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      height: s.h,
      padding: '0 ' + s.px + 'px',
      borderRadius: 'var(--radius-pill)',
      border: '1.5px solid ' + v.bd,
      background: h && !disabled ? v.bgH : v.bg,
      color: h && v.fgH && !disabled ? v.fgH : v.fg,
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: s.fs,
      letterSpacing: '0.005em',
      textDecoration: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .45 : 1,
      transform: a && !disabled ? 'scale(.97)' : 'none',
      transition: 'background var(--dur-base) var(--ease-organic),color var(--dur-base),transform var(--dur-fast) var(--ease-organic)',
      whiteSpace: 'nowrap',
      boxSizing: 'border-box',
      ...style
    }
  }, iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function IconButton({
  variant = 'ghost',
  size = 40,
  label,
  onClick,
  disabled,
  children,
  style
}) {
  const [h, setH] = React.useState(false);
  const map = {
    ghost: [h ? 'var(--agar-200)' : 'transparent', 'var(--abisal-800)', 'transparent'],
    outline: [h ? 'var(--biota-100)' : 'transparent', 'var(--abisal-800)', 'var(--border-subtle)'],
    solid: [h ? 'var(--biota-700)' : 'var(--abisal-800)', 'var(--agar-50)', 'transparent'],
    inverse: [h ? 'rgba(251,248,242,.14)' : 'transparent', 'var(--agar-50)', 'rgba(251,248,242,.3)']
  };
  const [bg, fg, bd] = map[variant] || map.ghost;
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    title: label,
    onClick: onClick,
    disabled: disabled,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      width: size,
      height: size,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: '50%',
      border: '1.5px solid ' + bd,
      background: bg,
      color: fg,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .45 : 1,
      padding: 0,
      transition: 'background var(--dur-base) var(--ease-organic)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
const PAL = {
  light: {
    ring: 'var(--abisal-800)',
    dot: 'var(--biota-500)',
    text: 'var(--abisal-800)'
  },
  inverse: {
    ring: 'var(--agar-50)',
    dot: 'var(--biota-300)',
    text: 'var(--agar-50)'
  },
  mono: {
    ring: 'currentColor',
    dot: 'currentColor',
    text: 'currentColor'
  }
};
function LogoSymbol({
  size = 40,
  tone = 'light',
  style
}) {
  const p = PAL[tone] || PAL.light;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 64 64",
    width: size,
    height: size,
    style: {
      display: 'block',
      flex: 'none',
      ...style
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "32",
    cy: "32",
    r: "23",
    fill: "none",
    stroke: p.ring,
    strokeWidth: "10"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "26",
    cy: "37",
    r: "7",
    fill: p.dot
  }));
}
function Logo({
  size = 32,
  tone = 'light',
  symbolOnly = false,
  tagline,
  style
}) {
  const p = PAL[tone] || PAL.light;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: size * 0.32,
      color: p.text,
      ...style
    },
    "aria-label": "BiotaScope"
  }, /*#__PURE__*/React.createElement(LogoSymbol, {
    size: size * 1.15,
    tone: tone
  }), !symbolOnly && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: size * 0.12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: size,
      lineHeight: .9,
      letterSpacing: '-0.055em',
      fontWeight: 700
    }
  }, "biotascope"), tagline && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: Math.max(10, size * 0.3),
      lineHeight: 1,
      letterSpacing: '0.02em',
      fontWeight: 400
    }
  }, tagline === true ? 'Meta-omic bioinformatics' : tagline)));
}
Object.assign(__ds_scope, { LogoSymbol, Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/brand/iconData.js
try { (() => {
// Generated: BiotaScope service icon set (48px grid, 2px round stroke + organic blob)
const ICON_BLOB = "M28 7c8.5 0 14 6.8 14 15.2 0 9.6-6.4 18.8-15.6 18.8C18 41 11 35.4 11 26.6 11 16.2 19 7 28 7z";
const ICON_TONES = {
  "ambar": "#EFC27E",
  "biota": "#8CC7B8",
  "liquen": "#D3DC7C",
  "arcilla": "#E8A686",
  "baya": "#D69BB8",
  "agua": "#A8CAD6"
};
const ICONS = {
  "meta-barcoding": {
    "label": "Meta-barcoding",
    "tone": "ambar",
    "rotate": 0,
    "paths": "<rect x=\"7\" y=\"11\" width=\"34\" height=\"26\" rx=\"6\"/><path d=\"M13 17v14M17 17v14M20 17v14M25 17v14M29 17v14M32 17v14M36 17v14\" stroke-width=\"2\"/><path d=\"M13 17v14M25 17v14\" stroke-width=\"3.2\"/>"
  },
  "analisis-taxonomico": {
    "label": "Análisis taxonómico",
    "tone": "biota",
    "rotate": 40,
    "paths": "<path d=\"M6 24h8M14 14v20M14 14h10M14 34h10M24 9v10M24 9h9M24 19h9M24 29v10M24 29h9M24 39h9\"/><circle cx=\"36.5\" cy=\"9\" r=\"2.8\"/><circle cx=\"36.5\" cy=\"19\" r=\"2.8\"/><circle cx=\"36.5\" cy=\"29\" r=\"2.8\"/><circle cx=\"36.5\" cy=\"39\" r=\"2.8\"/>"
  },
  "perfilado-funcional": {
    "label": "Perfilado funcional",
    "tone": "liquen",
    "rotate": -30,
    "paths": "<circle cx=\"11\" cy=\"12\" r=\"4\"/><circle cx=\"37\" cy=\"12\" r=\"4\"/><circle cx=\"24\" cy=\"25\" r=\"5\"/><circle cx=\"12\" cy=\"38\" r=\"4\"/><circle cx=\"37\" cy=\"37\" r=\"4\"/><path d=\"M14 15l6.5 6.5M34 15l-6.5 6.5M20.5 28.5L15 35M28 29l6 5.5\"/><path d=\"M33 34.5l1.2-3.4 3.3 1.3\" />"
  },
  "bioinformatica": {
    "label": "Bioinformática general",
    "tone": "agua",
    "rotate": 20,
    "paths": "<rect x=\"6\" y=\"9\" width=\"36\" height=\"30\" rx=\"6\"/><path d=\"M6 16h36\"/><path d=\"M15 23l-4 4 4 4M21 33l5-12M31 23l4 4-4 4\"/>"
  },
  "microbiota": {
    "label": "Microbiota",
    "tone": "baya",
    "rotate": -60,
    "paths": "<rect x=\"6\" y=\"16\" width=\"20\" height=\"9\" rx=\"4.5\" transform=\"rotate(-32 16 20.5)\"/><circle cx=\"32\" cy=\"14\" r=\"5\"/><circle cx=\"33\" cy=\"33\" r=\"7\"/><circle cx=\"15\" cy=\"35\" r=\"4\"/><circle cx=\"33\" cy=\"33\" r=\"1.6\" fill=\"#0F3D3E\" stroke=\"none\"/><path d=\"M38 20.5a3 3 0 0 1 3 3\"/>"
  },
  "microorganismos": {
    "label": "Microorganismos",
    "tone": "ambar",
    "rotate": 120,
    "paths": "<rect x=\"9\" y=\"17\" width=\"26\" height=\"12\" rx=\"6\" transform=\"rotate(-20 22 23)\"/><path d=\"M34.5 17.5c2.5-2 4-1 5.5-3s1.5-3.5 3-4.5M35.5 23c3 0 3.5 2 6 2M8.5 30c-2 2-1 4-3 5.5\"/><circle cx=\"18\" cy=\"24.5\" r=\"1.6\" fill=\"#0F3D3E\" stroke=\"none\"/><circle cx=\"25\" cy=\"21.5\" r=\"1.6\" fill=\"#0F3D3E\" stroke=\"none\"/>"
  },
  "muestras-ambientales": {
    "label": "Muestras ambientales",
    "tone": "liquen",
    "rotate": 70,
    "paths": "<path d=\"M17 6h14M19 6v27a5 5 0 0 0 10 0V6\"/><path d=\"M19 24h10\"/><path d=\"M24 24c0-6 3-9.5 8.5-10 0 5.5-3 9-8.5 10z\"/><path d=\"M8 42c5-3 11-3 16 0s11 3 16 0\"/>"
  },
  "farmacogenomica": {
    "label": "Farmacogenómica",
    "tone": "arcilla",
    "rotate": -10,
    "paths": "<rect x=\"6\" y=\"20\" width=\"24\" height=\"12\" rx=\"6\" transform=\"rotate(-40 18 26)\"/><path d=\"M13.5 30.5l9-7.5\"/><path d=\"M32 6c0 5 10 7 10 12s-10 7-10 12 10 7 10 12M42 6c0 5-10 7-10 12s10 7 10 12-10 7-10 12M33.5 12h7M33.5 24h7M33.5 36h7\"/>"
  },
  "rna-seq": {
    "label": "RNA-seq",
    "tone": "biota",
    "rotate": 160,
    "paths": "<path d=\"M5 24c4-9 8-9 12 0s8 9 12 0 8-9 12 0\"/><path d=\"M9 18v-5M17 24v-6M25 30v5M33 18v-5M41 24v-6\"/><circle cx=\"9\" cy=\"11\" r=\"2\"/><circle cx=\"33\" cy=\"11\" r=\"2\"/><circle cx=\"25\" cy=\"37\" r=\"2\"/>"
  },
  "scrna-seq": {
    "label": "scRNA-seq",
    "tone": "baya",
    "rotate": 90,
    "paths": "<circle cx=\"17\" cy=\"19\" r=\"10\"/><circle cx=\"17\" cy=\"19\" r=\"3.5\"/><circle cx=\"34\" cy=\"33\" r=\"2\"/><circle cx=\"39\" cy=\"27\" r=\"2\"/><circle cx=\"31\" cy=\"40\" r=\"2\"/><circle cx=\"40\" cy=\"37\" r=\"2\"/><circle cx=\"24\" cy=\"38\" r=\"2\"/><path d=\"M24 26l5 5\"/>"
  },
  "chip-seq": {
    "label": "ChIP-seq",
    "tone": "ambar",
    "rotate": -80,
    "paths": "<path d=\"M5 40h38\"/><path d=\"M5 40c3 0 4-3 6-3s3-17 5.5-17 3 17 5.5 17 2-9 4-9 2.5 9 4.5 9 3-25 5.5-25S39 40 43 40\"/>"
  },
  "variant-calling": {
    "label": "Variant calling",
    "tone": "arcilla",
    "rotate": 45,
    "paths": "<path d=\"M12 5c0 7 16 9 16 19s-16 12-16 19M28 5c0 7-16 9-16 19s16 12 16 19M14.5 11h11M13 24h14M14.5 37h11\"/><circle cx=\"36\" cy=\"24\" r=\"5.5\"/><path d=\"M27 24h3.5\"/>"
  },
  "resultados": {
    "label": "Resultados publicables",
    "tone": "agua",
    "rotate": -40,
    "paths": "<path d=\"M11 6h18l9 9v27H11z\"/><path d=\"M29 6v9h9\"/><path d=\"M17 36v-6M22.5 36v-11M28 36v-8M32.5 36v-4\"/>"
  },
  "consulta": {
    "label": "Plan de análisis",
    "tone": "liquen",
    "rotate": 10,
    "paths": "<path d=\"M8 12a5 5 0 0 1 5-5h22a5 5 0 0 1 5 5v15a5 5 0 0 1-5 5H20l-8 7v-7h1a5 5 0 0 1-5-5z\"/><path d=\"M16 17h16M16 23h10\"/>"
  }
};
Object.assign(__ds_scope, { ICON_BLOB, ICON_TONES, ICONS });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/iconData.js", error: String((e && e.message) || e) }); }

// components/brand/Icon.jsx
try { (() => {
function Icon({
  name,
  size = 48,
  tone,
  blob = true,
  color = 'var(--abisal-800)',
  style,
  title
}) {
  const d = __ds_scope.ICONS[name];
  if (!d) return null;
  const fill = __ds_scope.ICON_TONES[tone || d.tone] || tone;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 48 48",
    width: size,
    height: size,
    role: title ? 'img' : undefined,
    "aria-hidden": title ? undefined : true,
    style: {
      display: 'block',
      flex: 'none',
      ...style
    }
  }, title && /*#__PURE__*/React.createElement("title", null, title), blob && /*#__PURE__*/React.createElement("path", {
    d: __ds_scope.ICON_BLOB,
    fill: fill,
    transform: 'rotate(' + d.rotate + ' 26 24)'
  }), /*#__PURE__*/React.createElement("g", {
    fill: "none",
    stroke: color,
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    dangerouslySetInnerHTML: {
      __html: d.paths.split('#0F3D3E').join(color)
    }
  }));
}
const ICON_NAMES = Object.keys(__ds_scope.ICONS);
Object.assign(__ds_scope, { Icon, ICON_NAMES });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Icon.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
const T = {
  neutral: ['var(--agar-200)', 'var(--tinta-700)'],
  biota: ['var(--biota-100)', 'var(--biota-700)'],
  ambar: ['var(--ambar-100)', 'var(--ambar-700)'],
  arcilla: ['var(--arcilla-100)', 'var(--arcilla-600)'],
  baya: ['var(--baya-100)', 'var(--baya-600)'],
  agua: ['var(--agua-100)', 'var(--agua-600)'],
  liquen: ['var(--liquen-200)', '#5E6614'],
  inverse: ['var(--abisal-800)', 'var(--agar-50)']
};
function Badge({
  tone = 'biota',
  dot,
  children,
  style
}) {
  const [bg, fg] = T[tone] || T.biota;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 24,
      padding: '0 10px',
      borderRadius: 999,
      background: bg,
      color: fg,
      fontFamily: 'var(--font-sans)',
      fontSize: 12.5,
      fontWeight: 600,
      letterSpacing: '.01em',
      whiteSpace: 'nowrap',
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: fg
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
const T = {
  raised: {
    bg: 'var(--surface-card)',
    bd: 'var(--border-subtle)',
    fg: 'var(--text-body)'
  },
  tint: {
    bg: 'var(--surface-tint)',
    bd: 'transparent',
    fg: 'var(--text-body)'
  },
  warm: {
    bg: 'var(--surface-warm)',
    bd: 'transparent',
    fg: 'var(--text-body)'
  },
  inverse: {
    bg: 'var(--abisal-800)',
    bd: 'transparent',
    fg: 'var(--text-inverse-muted)'
  }
};
function Card({
  tone = 'raised',
  interactive,
  padding = 28,
  radius = 'var(--radius-lg)',
  onClick,
  children,
  style
}) {
  const [h, setH] = React.useState(false);
  const t = T[tone] || T.raised;
  const lift = interactive && h;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      background: t.bg,
      border: '1px solid ' + t.bd,
      borderRadius: radius,
      padding,
      color: t.fg,
      fontFamily: 'var(--font-sans)',
      boxShadow: lift ? 'var(--shadow-md)' : tone === 'raised' ? 'var(--shadow-xs)' : 'none',
      transform: lift ? 'translateY(-3px)' : 'none',
      transition: 'box-shadow var(--dur-slow) var(--ease-organic),transform var(--dur-slow) var(--ease-organic)',
      cursor: interactive ? 'pointer' : undefined,
      boxSizing: 'border-box',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/Tabs.jsx
try { (() => {
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  variant = 'pill',
  style
}) {
  const [inner, setInner] = React.useState(defaultValue ?? (tabs[0] && (tabs[0].value ?? tabs[0])));
  const cur = value ?? inner;
  const set = v => {
    setInner(v);
    onChange && onChange(v);
  };
  const pill = variant === 'pill';
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: 'inline-flex',
      gap: pill ? 4 : 28,
      padding: pill ? 4 : 0,
      borderRadius: 999,
      background: pill ? 'var(--agar-200)' : 'transparent',
      borderBottom: pill ? 'none' : '1px solid var(--border-subtle)',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, tabs.map(t => {
    const v = t.value ?? t,
      l = t.label ?? t,
      on = v === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      role: "tab",
      "aria-selected": on,
      onClick: () => set(v),
      style: pill ? {
        height: 38,
        padding: '0 18px',
        borderRadius: 999,
        border: 'none',
        background: on ? 'var(--agar-50)' : 'transparent',
        color: on ? 'var(--abisal-800)' : 'var(--text-muted)',
        fontWeight: 600,
        fontSize: 14.5,
        cursor: 'pointer',
        boxShadow: on ? 'var(--shadow-sm)' : 'none',
        transition: 'all var(--dur-base) var(--ease-organic)',
        fontFamily: 'inherit'
      } : {
        height: 44,
        padding: 0,
        border: 'none',
        borderBottom: '2px solid ' + (on ? 'var(--ambar-500)' : 'transparent'),
        marginBottom: -1,
        background: 'transparent',
        color: on ? 'var(--abisal-800)' : 'var(--text-muted)',
        fontWeight: 600,
        fontSize: 15,
        cursor: 'pointer',
        fontFamily: 'inherit'
      }
    }, l);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
function Tag({
  children,
  mono = true,
  selected,
  onClick,
  onRemove,
  style
}) {
  const [h, setH] = React.useState(false);
  const click = !!onClick;
  return /*#__PURE__*/React.createElement("span", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 28,
      padding: '0 12px',
      borderRadius: 999,
      border: '1px solid ' + (selected ? 'var(--abisal-800)' : 'var(--border-subtle)'),
      background: selected ? 'var(--abisal-800)' : click && h ? 'var(--agar-200)' : 'transparent',
      color: selected ? 'var(--agar-50)' : 'var(--tinta-700)',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      fontSize: 12.5,
      cursor: click ? 'pointer' : 'default',
      transition: 'background var(--dur-base) var(--ease-organic)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, children, onRemove && /*#__PURE__*/React.createElement("span", {
    role: "button",
    "aria-label": "Quitar",
    onClick: e => {
      e.stopPropagation();
      onRemove();
    },
    style: {
      cursor: 'pointer',
      opacity: .7,
      marginRight: -4
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open,
  onClose,
  title,
  children,
  footer,
  width = 520,
  style
}) {
  React.useEffect(() => {
    if (!open) return;
    const k = e => e.key === 'Escape' && onClose && onClose();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 100,
      background: 'var(--scrim)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation(),
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--bg-raised)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-lg)',
      padding: '32px 32px 28px',
      fontFamily: 'var(--font-sans)',
      color: 'var(--text-body)',
      position: 'relative',
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    "aria-label": "Cerrar",
    onClick: onClose,
    style: {
      position: 'absolute',
      top: 18,
      right: 18,
      width: 36,
      height: 36,
      borderRadius: '50%',
      border: '1px solid var(--border-subtle)',
      background: 'transparent',
      cursor: 'pointer',
      fontSize: 20,
      color: 'var(--abisal-800)',
      lineHeight: 1
    }
  }, "\xD7"), title && /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 40px 12px 0',
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 26,
      lineHeight: 1.15,
      color: 'var(--text-strong)',
      letterSpacing: '-0.03em'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      lineHeight: 1.6
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 12,
      marginTop: 24
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const T = {
  success: ['var(--biota-600)', '✓'],
  info: ['var(--agua-600)', 'i'],
  warning: ['var(--ambar-500)', '!'],
  danger: ['var(--arcilla-600)', '!']
};
function Toast({
  tone = 'success',
  title,
  children,
  onClose,
  style
}) {
  const [c, g] = T[tone] || T.success;
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 14,
      width: 380,
      maxWidth: '100%',
      boxSizing: 'border-box',
      padding: '16px 18px',
      borderRadius: 'var(--radius-md)',
      background: 'var(--abisal-800)',
      color: 'var(--text-inverse)',
      boxShadow: 'var(--shadow-lg)',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      width: 26,
      height: 26,
      borderRadius: '50%',
      background: c,
      color: 'var(--agar-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 13,
      fontWeight: 700
    }
  }, g), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 15,
      marginBottom: children ? 2 : 0
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--text-inverse-muted)'
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    "aria-label": "Cerrar",
    onClick: onClose,
    style: {
      border: 'none',
      background: 'transparent',
      color: 'var(--text-inverse-muted)',
      cursor: 'pointer',
      fontSize: 18,
      lineHeight: 1,
      padding: 0
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  content,
  placement = 'top',
  children,
  style
}) {
  const [o, setO] = React.useState(false);
  const pos = placement === 'bottom' ? {
    top: 'calc(100% + 8px)'
  } : {
    bottom: 'calc(100% + 8px)'
  };
  return /*#__PURE__*/React.createElement("span", {
    onMouseEnter: () => setO(true),
    onMouseLeave: () => setO(false),
    onFocus: () => setO(true),
    onBlur: () => setO(false),
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    }
  }, children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      left: '50%',
      ...pos,
      transform: 'translateX(-50%) translateY(' + (o ? 0 : 4) + 'px)',
      opacity: o ? 1 : 0,
      pointerEvents: 'none',
      transition: 'all var(--dur-base) var(--ease-organic)',
      background: 'var(--abisal-900)',
      color: 'var(--agar-50)',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      lineHeight: 1.4,
      padding: '7px 11px',
      borderRadius: 8,
      whiteSpace: 'nowrap',
      boxShadow: 'var(--shadow-md)',
      zIndex: 50
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled,
  error,
  style
}) {
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked ?? inner;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'flex-start',
      gap: 12,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      fontFamily: 'var(--font-sans)',
      fontSize: 15,
      lineHeight: 1.45,
      color: 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: on,
    disabled: disabled,
    onChange: e => {
      setInner(e.target.checked);
      onChange && onChange(e);
    },
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      width: 22,
      height: 22,
      marginTop: 1,
      borderRadius: 7,
      border: '1.5px solid ' + (error ? 'var(--danger)' : on ? 'var(--biota-600)' : 'var(--border-strong)'),
      background: on ? 'var(--biota-600)' : 'var(--bg-raised)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all var(--dur-base) var(--ease-organic)'
    }
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2.5 6.2l2.4 2.4 4.6-5",
    fill: "none",
    stroke: "var(--agar-50)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const baseField = (f, err) => ({
  width: '100%',
  boxSizing: 'border-box',
  minHeight: 48,
  padding: '12px 16px',
  borderRadius: 'var(--radius-sm)',
  border: '1.5px solid ' + (err ? 'var(--danger)' : f ? 'var(--border-focus)' : 'var(--border-subtle)'),
  background: 'var(--bg-raised)',
  color: 'var(--text-strong)',
  fontFamily: 'var(--font-sans)',
  fontSize: 16,
  outline: 'none',
  boxShadow: f ? '0 0 0 4px rgba(46,148,131,.16)' : 'none',
  transition: 'border-color var(--dur-fast),box-shadow var(--dur-base) var(--ease-organic)'
});
const Lbl = ({
  label,
  optional,
  htmlFor
}) => label ? /*#__PURE__*/React.createElement("label", {
  htmlFor: htmlFor,
  style: {
    fontFamily: 'var(--font-sans)',
    fontSize: 14,
    fontWeight: 600,
    color: 'var(--text-strong)'
  }
}, label, optional && /*#__PURE__*/React.createElement("span", {
  style: {
    fontWeight: 400,
    color: 'var(--text-muted)'
  }
}, " (opcional)")) : null;
const Msg = ({
  error,
  hint
}) => error || hint ? /*#__PURE__*/React.createElement("span", {
  style: {
    fontSize: 13,
    color: error ? 'var(--danger)' : 'var(--text-muted)',
    fontFamily: 'var(--font-sans)'
  }
}, error || hint) : null;
function Input({
  label,
  optional,
  hint,
  error,
  multiline,
  rows = 4,
  id,
  style,
  ...rest
}) {
  const [f, setF] = React.useState(false);
  const uid = id || React.useId();
  const T = multiline ? 'textarea' : 'input';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, /*#__PURE__*/React.createElement(Lbl, {
    label: label,
    optional: optional,
    htmlFor: uid
  }), /*#__PURE__*/React.createElement(T, _extends({
    id: uid,
    rows: multiline ? rows : undefined,
    onFocus: () => setF(true),
    onBlur: () => setF(false),
    "aria-invalid": !!error
  }, rest, {
    style: {
      ...baseField(f, error),
      resize: multiline ? 'vertical' : undefined,
      lineHeight: 1.5
    }
  })), /*#__PURE__*/React.createElement(Msg, {
    error: error,
    hint: hint
  }));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  label,
  name,
  value,
  checked,
  defaultChecked,
  onChange,
  disabled,
  style
}) {
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked ?? inner;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      fontFamily: 'var(--font-sans)',
      fontSize: 15,
      color: 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    defaultChecked: defaultChecked,
    disabled: disabled,
    onChange: e => {
      setInner(e.target.checked);
      onChange && onChange(e);
    },
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      width: 22,
      height: 22,
      borderRadius: '50%',
      border: '1.5px solid ' + (on ? 'var(--biota-600)' : 'var(--border-strong)'),
      background: 'var(--bg-raised)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: 'var(--biota-600)',
      transform: on ? 'scale(1)' : 'scale(0)',
      transition: 'transform var(--dur-base) var(--ease-organic)'
    }
  })), label);
}
function RadioGroup({
  name,
  options = [],
  value,
  onChange,
  direction = 'column',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "radiogroup",
    style: {
      display: 'flex',
      flexDirection: direction,
      gap: direction === 'row' ? 20 : 10,
      ...style
    }
  }, options.map(o => /*#__PURE__*/React.createElement(Radio, {
    key: o,
    name: name,
    value: o,
    label: o,
    checked: value === undefined ? undefined : value === o,
    onChange: () => onChange && onChange(o)
  })));
}
Object.assign(__ds_scope, { Radio, RadioGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const baseField = (f, err) => ({
  width: '100%',
  boxSizing: 'border-box',
  minHeight: 48,
  padding: '12px 16px',
  borderRadius: 'var(--radius-sm)',
  border: '1.5px solid ' + (err ? 'var(--danger)' : f ? 'var(--border-focus)' : 'var(--border-subtle)'),
  background: 'var(--bg-raised)',
  color: 'var(--text-strong)',
  fontFamily: 'var(--font-sans)',
  fontSize: 16,
  outline: 'none',
  boxShadow: f ? '0 0 0 4px rgba(46,148,131,.16)' : 'none',
  transition: 'border-color var(--dur-fast),box-shadow var(--dur-base) var(--ease-organic)'
});
const Lbl = ({
  label,
  optional,
  htmlFor
}) => label ? /*#__PURE__*/React.createElement("label", {
  htmlFor: htmlFor,
  style: {
    fontFamily: 'var(--font-sans)',
    fontSize: 14,
    fontWeight: 600,
    color: 'var(--text-strong)'
  }
}, label, optional && /*#__PURE__*/React.createElement("span", {
  style: {
    fontWeight: 400,
    color: 'var(--text-muted)'
  }
}, " (opcional)")) : null;
const Msg = ({
  error,
  hint
}) => error || hint ? /*#__PURE__*/React.createElement("span", {
  style: {
    fontSize: 13,
    color: error ? 'var(--danger)' : 'var(--text-muted)',
    fontFamily: 'var(--font-sans)'
  }
}, error || hint) : null;
function Select({
  label,
  optional,
  hint,
  error,
  options = [],
  placeholder = 'Selecciona una opción…',
  id,
  style,
  value,
  defaultValue,
  onChange,
  ...rest
}) {
  const [f, setF] = React.useState(false);
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, /*#__PURE__*/React.createElement(Lbl, {
    label: label,
    optional: optional,
    htmlFor: uid
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: uid,
    value: value,
    defaultValue: value === undefined ? defaultValue ?? '' : undefined,
    onChange: onChange,
    onFocus: () => setF(true),
    onBlur: () => setF(false)
  }, rest, {
    style: {
      ...baseField(f, error),
      appearance: 'none',
      paddingRight: 44,
      cursor: 'pointer'
    }
  }), /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), options.map(o => {
    const v = typeof o === 'string' ? o : o.value,
      l = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    style: {
      position: 'absolute',
      right: 18,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 5l5 5 5-5",
    fill: "none",
    stroke: "var(--abisal-800)",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), /*#__PURE__*/React.createElement(Msg, {
    error: error,
    hint: hint
  }));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled,
  style
}) {
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked ?? inner;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      fontFamily: 'var(--font-sans)',
      fontSize: 15,
      color: 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    role: "switch",
    checked: on,
    disabled: disabled,
    onChange: e => {
      setInner(e.target.checked);
      onChange && onChange(e.target.checked);
    },
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      width: 44,
      height: 26,
      borderRadius: 999,
      background: on ? 'var(--biota-600)' : 'var(--agar-300)',
      position: 'relative',
      transition: 'background var(--dur-base) var(--ease-organic)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: on ? 21 : 3,
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: 'var(--agar-50)',
      boxShadow: 'var(--shadow-sm)',
      transition: 'left var(--dur-base) var(--ease-organic)'
    }
  })), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/About.jsx
try { (() => {
const {
  Icon: AI
} = window.BiotaScopeDesignSystem_24580f;
function About({
  lang
}) {
  const es = lang === 'es';
  const steps = es ? [['consulta', 'Plan acordado', 'Definimos contigo el plan de análisis antes de empezar.'], ['bioinformatica', 'Análisis reproducible', 'Pipelines documentados y versionados.'], ['resultados', 'Entrega publicable', 'Figuras, tablas y métodos listos para el manuscrito.']] : [['consulta', 'Agreed plan', 'We define the analysis plan with you before starting.'], ['bioinformatica', 'Reproducible analysis', 'Documented, versioned pipelines.'], ['resultados', 'Publishable delivery', 'Figures, tables and methods ready for the manuscript.']];
  return /*#__PURE__*/React.createElement("section", {
    id: "sobre",
    className: "section",
    style: {
      background: 'var(--bg-inverse)',
      color: 'var(--text-inverse-muted)',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "blob",
    style: {
      width: 420,
      height: 380,
      background: 'var(--biota-500)',
      left: -140,
      top: -120,
      opacity: .45
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "blob",
    style: {
      width: 300,
      height: 260,
      background: 'var(--ambar-500)',
      right: -60,
      bottom: -80,
      opacity: .35
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      position: 'relative',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 64,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      aspectRatio: '4/3.4'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/images/laboratorio.png",
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      color: 'var(--liquen-300)'
    }
  }, /*#__PURE__*/React.createElement("i", null), es ? 'Sobre BiotaScope' : 'About BiotaScope'), /*#__PURE__*/React.createElement("h2", {
    className: "h2",
    style: {
      color: 'var(--agar-50)',
      margin: '16px 0 20px'
    }
  }, es ? /*#__PURE__*/React.createElement(React.Fragment, null, "Datos de secuenciaci\xF3n convertidos en ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: 'normal',
      color: 'var(--liquen-300)'
    }
  }, "respuestas")) : /*#__PURE__*/React.createElement(React.Fragment, null, "Sequencing data turned into ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: 'normal',
      color: 'var(--liquen-300)'
    }
  }, "answers"))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      lineHeight: 1.65,
      margin: '0 0 32px'
    }
  }, es ? 'BiotaScope es un servicio especializado en análisis bioinformático meta-ómico. Trabajamos con grupos de investigación y empresas que necesitan convertir datos de secuenciación en resultados interpretables.' : 'BiotaScope is a service specialised in meta-omic bioinformatic analysis. We work with research groups and companies that need to turn sequencing data into interpretable results.'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, steps.map(([ic, t, d]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(AI, {
    name: ic,
    size: 44,
    color: "var(--agar-50)",
    tone: "rgba(255,255,255,.14)"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--agar-50)',
      fontWeight: 600
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5
    }
  }, d))))))));
}
window.About = About;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/About.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Contact.jsx
try { (() => {
const {
  Input: CI,
  Select: CS,
  Checkbox: CC,
  Button: CB,
  Toast: CT
} = window.BiotaScopeDesignSystem_24580f;
function Contact({
  lang
}) {
  const es = lang === 'es';
  const [v, setV] = React.useState({
    name: '',
    email: '',
    org: '',
    svc: '',
    msg: '',
    ok: false
  });
  const [err, setErr] = React.useState({});
  const [sent, setSent] = React.useState(false);
  const up = k => e => setV({
    ...v,
    [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value
  });
  const submit = e => {
    e.preventDefault();
    const E = {};
    if (!v.name) E.name = es ? 'Escribe tu nombre.' : 'Enter your name.';
    if (!/.+@.+\..+/.test(v.email)) E.email = es ? 'Escribe un email válido.' : 'Enter a valid email.';
    if (!v.svc) E.svc = es ? 'Elige un servicio.' : 'Choose a service.';
    if (!v.msg) E.msg = es ? 'Cuéntanos algo sobre el proyecto.' : 'Tell us about the project.';
    if (!v.ok) E.ok = true;
    setErr(E);
    if (!Object.keys(E).length) {
      setSent(true);
      setTimeout(() => setSent(false), 5000);
    }
  };
  return /*#__PURE__*/React.createElement("section", {
    id: "contacto",
    className: "section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,.9fr) minmax(0,1.1fr)',
      gap: 64
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, /*#__PURE__*/React.createElement("i", null), es ? 'Contacto' : 'Contact'), /*#__PURE__*/React.createElement("h2", {
    className: "h2",
    style: {
      margin: '16px 0 20px'
    }
  }, es ? 'Cuéntanos tu proyecto' : 'Tell us about your project'), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      lineHeight: 1.6,
      margin: '0 0 28px'
    }
  }, es ? 'Descríbenos el proyecto en un par de frases y te respondemos con una primera valoración.' : 'Describe the project in a couple of sentences and we will reply with a first assessment.'), /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-cell)',
      overflow: 'hidden',
      width: '78%',
      aspectRatio: '1/1'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/images/microbiota.png",
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 28,
      color: 'var(--text-muted)'
    }
  }, es ? 'O escríbenos a' : 'Or write to', " ", /*#__PURE__*/React.createElement("a", {
    href: "mailto:angel@biotascope.com"
  }, "angel@biotascope.com"))), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    noValidate: true,
    style: {
      background: 'var(--bg-raised)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-xl)',
      padding: 36,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 20,
      boxShadow: 'var(--shadow-sm)',
      alignSelf: 'start'
    }
  }, /*#__PURE__*/React.createElement(CI, {
    label: es ? 'Nombre' : 'Name',
    value: v.name,
    onChange: up('name'),
    error: err.name
  }), /*#__PURE__*/React.createElement(CI, {
    label: "Email",
    type: "email",
    value: v.email,
    onChange: up('email'),
    error: err.email
  }), /*#__PURE__*/React.createElement(CI, {
    label: es ? 'Organización' : 'Organisation',
    optional: true,
    value: v.org,
    onChange: up('org')
  }), /*#__PURE__*/React.createElement(CS, {
    label: es ? 'Servicio' : 'Service',
    value: v.svc,
    onChange: up('svc'),
    error: err.svc,
    placeholder: es ? 'Selecciona una opción…' : 'Select an option…',
    options: ['Meta-barcoding', es ? 'Análisis taxonómico' : 'Taxonomic analysis', es ? 'Perfilado funcional' : 'Functional profiling', es ? 'Bioinformática general' : 'General bioinformatics', es ? 'Otra consulta' : 'Other']
  }), /*#__PURE__*/React.createElement(CI, {
    style: {
      gridColumn: '1/-1'
    },
    label: es ? 'Mensaje' : 'Message',
    multiline: true,
    rows: 5,
    value: v.msg,
    onChange: up('msg'),
    error: err.msg
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1/-1',
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(CC, {
    checked: v.ok,
    onChange: up('ok'),
    error: err.ok,
    label: es ? 'Acepto que se use mi email para responder a esta consulta.' : 'I agree my email is used to reply to this enquiry.'
  }), err.ok && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--danger)',
      marginLeft: 34
    }
  }, es ? 'Necesitamos tu consentimiento para responderte.' : 'We need your consent to reply.')), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1/-1'
    }
  }, /*#__PURE__*/React.createElement(CB, {
    type: "submit",
    size: "lg",
    variant: "accent",
    iconRight: /*#__PURE__*/React.createElement("span", null, "\u2192")
  }, es ? 'Enviar consulta' : 'Send enquiry')))), sent && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      right: 24,
      bottom: 24,
      zIndex: 95
    }
  }, /*#__PURE__*/React.createElement(CT, {
    title: es ? 'Consulta enviada' : 'Enquiry sent',
    onClose: () => setSent(false)
  }, es ? 'Te respondemos con una primera valoración.' : 'We will reply with a first assessment.')));
}
window.Contact = Contact;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Contact.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
const {
  Logo: FL
} = window.BiotaScopeDesignSystem_24580f;
function SiteFooter({
  lang
}) {
  const es = lang === 'es';
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--abisal-900)',
      color: 'var(--text-inverse-muted)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '56px var(--container-pad) 32px',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.3fr) minmax(0,1fr)',
      gap: 48
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(FL, {
    tone: "inverse",
    size: 26,
    tagline: true
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '18px 0 0',
      maxWidth: '30em',
      lineHeight: 1.6,
      fontSize: 15
    }
  }, es ? 'Servicios bioinformáticos especializados en análisis meta-ómicos (microbiota, muestras ambientales) y datos ómicos.' : 'Bioinformatic services specialised in meta-omic analysis (microbiota, environmental samples) and omics data.')), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 28,
      justifyContent: 'flex-end',
      alignItems: 'flex-start',
      flexWrap: 'wrap'
    }
  }, [[es ? 'Servicios' : 'Services', 'servicios'], [es ? 'Resultados' : 'Results', 'resultados'], [es ? 'Contacto' : 'Contact', 'contacto']].map(([l, h]) => /*#__PURE__*/React.createElement("a", {
    key: h,
    href: '#' + h,
    className: "footlink"
  }, l)), /*#__PURE__*/React.createElement("a", {
    className: "footlink",
    href: "mailto:angel@biotascope.com"
  }, "angel@biotascope.com")), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1/-1',
      borderTop: '1px solid rgba(255,255,255,.14)',
      paddingTop: 20,
      fontSize: 13
    }
  }, "\xA9 2025 BiotaScope")));
}
window.SiteFooter = SiteFooter;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
const {
  Logo,
  Button,
  IconButton
} = window.BiotaScopeDesignSystem_24580f;
function SiteHeader({
  lang,
  setLang
}) {
  const [s, setS] = React.useState(false);
  React.useEffect(() => {
    const f = () => setS(window.scrollY > 24);
    window.addEventListener('scroll', f);
    return () => window.removeEventListener('scroll', f);
  }, []);
  const t = lang === 'es' ? ['Servicios', 'Resultados', 'Sobre BiotaScope', 'Contacto', 'Solicitar presupuesto'] : ['Services', 'Results', 'About', 'Contact', 'Request a quote'];
  const ids = ['servicios', 'resultados', 'sobre', 'contacto'];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 40,
      background: s ? 'var(--glass)' : 'transparent',
      backdropFilter: s ? 'blur(var(--blur-glass))' : 'none',
      borderBottom: '1px solid ' + (s ? 'var(--border-subtle)' : 'transparent'),
      transition: 'all var(--dur-slow) var(--ease-organic)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--container-pad)',
      height: 76,
      display: 'flex',
      alignItems: 'center',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    style: {
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    size: 24
  })), /*#__PURE__*/React.createElement("nav", {
    className: "sitenav",
    style: {
      display: 'flex',
      gap: 22,
      marginLeft: 'auto'
    }
  }, t.slice(0, 4).map((l, i) => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: '#' + ids[i],
    className: "navlink"
  }, l))), /*#__PURE__*/React.createElement("span", {
    className: "navspacer",
    style: {
      marginLeft: 'auto'
    }
  }), /*#__PURE__*/React.createElement(IconButton, {
    label: "Cambiar idioma",
    variant: "outline",
    size: 38,
    onClick: () => setLang(lang === 'es' ? 'en' : 'es')
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 700
    }
  }, lang === 'es' ? 'EN' : 'ES')), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    href: "#contacto"
  }, t[4])));
}
window.SiteHeader = SiteHeader;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
const {
  Button: HB,
  Tag: HT
} = window.BiotaScopeDesignSystem_24580f;
function Hero({
  lang
}) {
  const es = lang === 'es';
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    style: {
      position: 'relative',
      overflow: 'hidden',
      marginTop: -76,
      paddingTop: 76
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "blob",
    style: {
      width: 520,
      height: 440,
      background: 'var(--liquen-300)',
      right: -120,
      top: -60
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "blob",
    style: {
      width: 380,
      height: 320,
      background: 'var(--agua-300)',
      right: 260,
      top: 260
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "blob",
    style: {
      width: 260,
      height: 240,
      background: 'var(--ambar-300)',
      left: -80,
      bottom: 40
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '72px var(--container-pad) 88px',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.15fr) minmax(0,1fr)',
      gap: 56,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, /*#__PURE__*/React.createElement("i", null), es ? 'Bioinformática meta-ómica' : 'Meta-omic bioinformatics'), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: '600 clamp(44px,5.4vw,76px)/1.02 var(--font-display)',
      letterSpacing: '-0.045em',
      color: 'var(--text-strong)',
      margin: '22px 0 24px',
      textWrap: 'balance'
    }
  }, es ? /*#__PURE__*/React.createElement(React.Fragment, null, "De secuencias crudas a resultados que puedes ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: 'normal',
      color: 'var(--biota-600)'
    }
  }, "publicar")) : /*#__PURE__*/React.createElement(React.Fragment, null, "From raw reads to results you can ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: 'normal',
      color: 'var(--biota-600)'
    }
  }, "publish"))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-l)',
      lineHeight: 1.6,
      maxWidth: '34em',
      margin: '0 0 36px',
      textWrap: 'pretty'
    }
  }, es ? 'Análisis bioinformático de microbiota, muestras ambientales y datos ómicos para grupos de investigación y empresas.' : 'Bioinformatic analysis of microbiota, environmental samples and omics data for research groups and companies.'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(HB, {
    size: "lg",
    href: "#contacto",
    iconRight: /*#__PURE__*/React.createElement("span", null, "\u2192")
  }, es ? 'Solicitar presupuesto' : 'Request a quote'), /*#__PURE__*/React.createElement(HB, {
    size: "lg",
    variant: "secondary",
    href: "#resultados"
  }, es ? 'Ver resultados' : 'See results'))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '1/1'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 'var(--radius-cell)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-lg)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/images/microorganismos.png",
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: -28,
      bottom: 36,
      background: 'var(--bg-raised)',
      borderRadius: 'var(--radius-md)',
      padding: '14px 18px',
      boxShadow: 'var(--shadow-md)',
      display: 'flex',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: 'var(--biota-500)',
      boxShadow: 'var(--shadow-glow)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 13px var(--font-mono)',
      color: 'var(--tinta-700)'
    }
  }, "16S \xB7 1.2M reads \xB7 248 ASV")))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      borderTop: '1px solid var(--border-subtle)',
      borderBottom: '1px solid var(--border-subtle)',
      background: 'var(--agar-100)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '18px var(--container-pad)',
      display: 'flex',
      alignItems: 'center',
      gap: 20,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow",
    style: {
      color: 'var(--text-muted)'
    }
  }, es ? 'Tecnologías' : 'Technologies'), ['QIIME2', 'PICRUSt2', 'Kraken2', 'Bracken', 'HUMAnN3', 'RNA-seq', 'ChIP-seq'].map(x => /*#__PURE__*/React.createElement(HT, {
    key: x
  }, x)))));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Results.jsx
try { (() => {
const {
  Tabs: RT,
  IconButton: RIB,
  Icon: RI
} = window.BiotaScopeDesignSystem_24580f;
const FIGS = [['Composición taxonómica', 'QIIME2', 'tax', 'ambar'], ['Predicción funcional', 'PICRUSt2', 'fun', 'liquen'], ['Jerarquía taxonómica', 'Krona', 'tax', 'baya'], ['Abundancia diferencial', 'Volcano plot', 'dif', 'arcilla'], ['Rutas metabólicas', 'Heatmap funcional', 'fun', 'biota'], ['Rutas diferenciales', 'Gráfico de barras', 'dif', 'agua']];
function Figure({
  f,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    className: "fig",
    style: {
      all: 'unset',
      cursor: 'zoom-in',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4/3',
      borderRadius: 'var(--radius-md)',
      background: 'var(--bg-sunken)',
      border: '1px dashed var(--agar-300)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      transition: 'transform var(--dur-slow) var(--ease-organic),box-shadow var(--dur-slow) var(--ease-organic)'
    }
  }, /*#__PURE__*/React.createElement(RI, {
    name: "resultados",
    size: 44,
    tone: f[3]
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '11px var(--font-mono)',
      color: 'var(--text-muted)'
    }
  }, "figura \xB7 ", f[1])), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14.5,
      color: 'var(--text-strong)'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 600
    }
  }, f[0]), " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "\xB7 ", f[1])));
}
function Results({
  lang
}) {
  const es = lang === 'es';
  const [cat, setCat] = React.useState('all');
  const [open, setOpen] = React.useState(-1);
  const list = FIGS.map((f, i) => [f, i]).filter(([f]) => cat === 'all' || f[2] === cat);
  React.useEffect(() => {
    if (open < 0) return;
    const k = e => {
      if (e.key === 'Escape') setOpen(-1);
      if (e.key === 'ArrowRight') setOpen(o => (o + 1) % 6);
      if (e.key === 'ArrowLeft') setOpen(o => (o + 5) % 6);
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open]);
  return /*#__PURE__*/React.createElement("section", {
    id: "resultados",
    className: "section",
    style: {
      background: 'var(--bg-raised)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, /*#__PURE__*/React.createElement("i", null), es ? 'Resultados' : 'Results'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 24,
      flexWrap: 'wrap',
      margin: '16px 0 40px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    className: "h2"
  }, es ? 'Ejemplos de análisis' : 'Analysis examples'), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '12px 0 0',
      color: 'var(--text-muted)'
    }
  }, es ? 'Pulsa en cualquier figura para verla a tamaño completo.' : 'Click any figure to view it full size.')), /*#__PURE__*/React.createElement(RT, {
    value: cat,
    onChange: setCat,
    tabs: [{
      value: 'all',
      label: es ? 'Todos' : 'All'
    }, {
      value: 'tax',
      label: es ? 'Taxonomía' : 'Taxonomy'
    }, {
      value: 'fun',
      label: es ? 'Funcional' : 'Functional'
    }, {
      value: 'dif',
      label: es ? 'Diferencial' : 'Differential'
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))',
      gap: '32px 24px'
    }
  }, list.map(([f, i]) => /*#__PURE__*/React.createElement(Figure, {
    key: i,
    f: f,
    onClick: () => setOpen(i)
  })))), open >= 0 && /*#__PURE__*/React.createElement("div", {
    onClick: () => setOpen(-1),
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 90,
      background: 'var(--scrim)',
      backdropFilter: 'blur(6px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 24,
      padding: 32
    }
  }, /*#__PURE__*/React.createElement(RIB, {
    label: "Anterior",
    variant: "inverse",
    size: 48,
    onClick: e => {
      e.stopPropagation();
      setOpen((open + 5) % 6);
    }
  }, "\u2039"), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: 'min(900px,75vw)',
      background: 'var(--agar-50)',
      borderRadius: 'var(--radius-lg)',
      padding: 20,
      boxShadow: 'var(--shadow-lg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '16/10',
      background: 'var(--bg-sunken)',
      borderRadius: 'var(--radius-md)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(RI, {
    name: "resultados",
    size: 80,
    tone: FIGS[open][3]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginTop: 14,
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", null, FIGS[open][0]), " \xB7 ", FIGS[open][1]), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '12px var(--font-mono)',
      color: 'var(--text-muted)'
    }
  }, open + 1, " / 6"))), /*#__PURE__*/React.createElement(RIB, {
    label: "Siguiente",
    variant: "inverse",
    size: 48,
    onClick: e => {
      e.stopPropagation();
      setOpen((open + 1) % 6);
    }
  }, "\u203A"), /*#__PURE__*/React.createElement(RIB, {
    label: "Cerrar",
    variant: "inverse",
    style: {
      position: 'absolute',
      top: 24,
      right: 24
    },
    onClick: () => setOpen(-1)
  }, "\xD7")));
}
window.Results = Results;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Results.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Services.jsx
try { (() => {
const {
  Card: SC,
  Icon: SI,
  Tag: ST
} = window.BiotaScopeDesignSystem_24580f;
const SERVICES = {
  es: [['meta-barcoding', 'Meta-barcoding', 'Clasificación taxonómica y predicción funcional de comunidades microbianas a partir de secuencias amplificadas de 16S/ITS con QIIME2 y PICRUSt2.', ['QIIME2', 'PICRUSt2', '16S', 'ITS']], ['analisis-taxonomico', 'Análisis taxonómico', 'Identificación taxonómica mediante alineamiento con bases de datos personalizadas utilizando Kraken2 y Bracken.', ['Kraken2', 'Bracken', 'Krona', 'Shotgun']], ['perfilado-funcional', 'Perfilado funcional', 'Perfilado de rutas metabólicas mediante alineamiento funcional y enriquecimiento, útil para caracterizar el potencial funcional de microbiotas complejas.', ['HUMAnN3', 'MetaCyc', 'UniRef']], ['bioinformatica', 'Bioinformática general', 'Procesamiento de datos genómicos y transcriptómicos, con herramientas adaptadas a distintos diseños experimentales.', ['RNA-seq', 'scRNA-seq', 'ChIP-seq', 'Variant calling']]],
  en: [['meta-barcoding', 'Meta-barcoding', 'Taxonomic classification and functional prediction of microbial communities from 16S/ITS amplicons with QIIME2 and PICRUSt2.', ['QIIME2', 'PICRUSt2', '16S', 'ITS']], ['analisis-taxonomico', 'Taxonomic analysis', 'Taxonomic identification by alignment against custom databases using Kraken2 and Bracken.', ['Kraken2', 'Bracken', 'Krona', 'Shotgun']], ['perfilado-funcional', 'Functional profiling', 'Metabolic pathway profiling through functional alignment and enrichment, to characterise the functional potential of complex microbiota.', ['HUMAnN3', 'MetaCyc', 'UniRef']], ['bioinformatica', 'General bioinformatics', 'Processing of genomic and transcriptomic data, with tools adapted to different experimental designs.', ['RNA-seq', 'scRNA-seq', 'ChIP-seq', 'Variant calling']]]
};
function Services({
  lang
}) {
  const es = lang === 'es';
  return /*#__PURE__*/React.createElement("section", {
    id: "servicios",
    className: "section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, /*#__PURE__*/React.createElement("i", null), es ? 'Servicios' : 'Services'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 24,
      flexWrap: 'wrap',
      margin: '16px 0 48px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "h2"
  }, es ? 'Qué hacemos' : 'What we do'), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-muted)',
      maxWidth: '28em'
    }
  }, es ? 'Cada análisis se adapta al diseño experimental del proyecto.' : 'Every analysis adapts to the experimental design of the project.')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))',
      gap: 20
    }
  }, SERVICES[lang].map(([ic, t, d, tags]) => /*#__PURE__*/React.createElement(SC, {
    key: ic,
    interactive: true,
    padding: 30,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(SI, {
    name: ic,
    size: 60
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: '600 22px/1.2 var(--font-display)',
      color: 'var(--text-strong)',
      margin: '6px 0 0',
      letterSpacing: '-0.03em'
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15.5,
      lineHeight: 1.6,
      flex: 1
    }
  }, d), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, tags.map(x => /*#__PURE__*/React.createElement(ST, {
    key: x
  }, x))))))));
}
window.Services = Services;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Services.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.ICON_NAMES = __ds_scope.ICON_NAMES;

__ds_ns.LogoSymbol = __ds_scope.LogoSymbol;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.ICON_BLOB = __ds_scope.ICON_BLOB;

__ds_ns.ICON_TONES = __ds_scope.ICON_TONES;

__ds_ns.ICONS = __ds_scope.ICONS;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.RadioGroup = __ds_scope.RadioGroup;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

})();
